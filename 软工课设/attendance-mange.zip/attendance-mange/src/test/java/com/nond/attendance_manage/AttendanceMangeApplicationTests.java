package com.nond.attendance_manage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendanceMangeApplicationTests {

    @Test
    void contextLoads() {
    }

}
