CREATE TABLE IF NOT EXISTS Employee
(
    id         INT PRIMARY KEY AUTO_INCREMENT,
    name       VARCHAR(20) NOT NULL,
    isFlexible BOOL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS ClockRecord
(
    id         INT PRIMARY KEY AUTO_INCREMENT,
    employeeID INT        NOT NULL,
    clockType  VARCHAR(3) NOT NULL,
    clockTime  datetime   NOT NULL,
    date       date       NOT NULL,
    CONSTRAINT fk_ck foreign key (employeeID) references Employee (id)
);

CREATE TABLE IF NOT EXISTS Manager
(
    id       INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(20) NOT NULL unique,
    password VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS WorkArrange
(
    id         INT PRIMARY KEY AUTO_INCREMENT,
    employeeID INT  NOT NULL,
    startTime  time NOT NULL,
    endTime    time NOT NULL,
    date       date NOT NULL,
    CONSTRAINT fk_we1 foreign key (employeeID) references Employee (id)
);

CREATE TABLE IF NOT EXISTS WorkLengthRequired
(
    id         INT PRIMARY KEY AUTO_INCREMENT,
    employeeID INT        NOT NULL,
    length     float      NOT NULL,
    date       VARCHAR(7) NOT NULL,
    CONSTRAINT fk_we2 foreign key (employeeID) references Employee (id)
);

create table if not exists WorkStatistic_Flex
(
    id            INT PRIMARY KEY AUTO_INCREMENT,
    employeeID    INT   NOT NULL,
    length        float NOT NULL,
    earningLength float NOT NULL,
    date          date  NOT NULL
);

create table if not exists WorkStatistic_Day
(
    id          INT PRIMARY KEY AUTO_INCREMENT,
    employeeID  INT NOT NULL,
    startTime   time,
    endTime     time,
    date        date,
    isLateStart BOOL,
    isEarlyQuit BOOL,
    CONSTRAINT fk_we3 foreign key (employeeID) references Employee (id)
);

create table if not exists WorkStatistic_Month
(
    id         INT PRIMARY KEY AUTO_INCREMENT,
    employeeID INT        NOT NULL,
    workCount  float      NOT NULL,
    date       VARCHAR(7) NOT NULL,
    isFinish   BOOL,
    CONSTRAINT fk_we4 foreign key (employeeID) references Employee (id)
);