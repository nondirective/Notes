package com.nond.attendance_manage.model.TO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class WorkLengthRequiredTO {
    private String name;
    private float length;
    private String date;
    private boolean setAll;

//    public void setDate(String string){
//        String splits[] = string.split("-");
//        Date date = new Date();
//        date.setYear(Integer.parseInt(splits[0])-1900);
//        date.setMonth(Integer.parseInt(splits[1])-1);
//        this.date = date;
//    }

    public void setSetAll(String string){
        this.setAll = string.equals("true")?true:false;
    }
}
