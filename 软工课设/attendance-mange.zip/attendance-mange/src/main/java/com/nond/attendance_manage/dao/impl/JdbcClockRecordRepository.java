package com.nond.attendance_manage.dao.impl;

import com.nond.attendance_manage.dao.ClockRecordRepository;
import com.nond.attendance_manage.model.ClockRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import static com.nond.attendance_manage.model.ClockRecord.ClockType;

@Repository
public class JdbcClockRecordRepository implements ClockRecordRepository {
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public JdbcClockRecordRepository(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Iterable<ClockRecord> findByDate(Date date) {
        return jdbcTemplate.query(
                "select * from ClockRecord where date = ?",
                this::mapRow2ClockRecord,
                new java.sql.Date(date.getTime()));
    }

    @Override
    public Iterable<ClockRecord> findByID(int employeeID) {
        return jdbcTemplate.query(
                "select * from ClockRecord where employeeID = ?",
                this::mapRow2ClockRecord,
                employeeID);
    }

    @Override
    public Iterable<ClockRecord> findByID_Type_Month(int employeeID, Date date,ClockType clockType) {
        java.sql.Date start = new java.sql.Date(date.getTime());
        start.setDate(1);
        java.sql.Date end = new java.sql.Date(date.getTime());
        return jdbcTemplate.query(
                "select * from ClockRecord where date>=? and date<=? and employeeID=? and ClockType=?",
                this::mapRow2ClockRecord,
                start,end,employeeID,clockType.name()
        );
    }

    @Override
    public ClockRecord findByID_Date_Type(int employeeID, Date date, ClockType type) {
        try {
            return jdbcTemplate.queryForObject(
                    "select * from ClockRecord where employeeID = ? and date = ? and ClockType = ?",
                    this::mapRow2ClockRecord,
                    employeeID,
                    new java.sql.Date(date.getTime()),
                    type.name()
            );
        }catch(Exception e){
            return null;
        }
    }
    //ClockRecord Dao实现
    @Override
    public ClockRecord save(ClockRecord clockRecord) {
        clockRecord.setClockTime(new Date());
        jdbcTemplate.update(
                "insert into clockRecord(employeeID,clockType,clockTime,date) values(?,?,?,?)",
                clockRecord.getEmployeeID(),
                clockRecord.getClockType().name(),
                new Timestamp(clockRecord.getClockTime().getTime()),
                new java.sql.Date(clockRecord.getClockTime().getTime()));
        return clockRecord;
    }

    ClockRecord mapRow2ClockRecord(ResultSet resultSet,int rowNum) throws SQLException {
        return new ClockRecord(
                resultSet.getInt("id"),
                resultSet.getInt("employeeID"),
                ClockRecord.ClockType.valueOf(resultSet.getString("clockType")),
                new Date(resultSet.getTimestamp("clockTime").getTime()),
                new Date(resultSet.getDate("date").getTime())
        );
    }
}
