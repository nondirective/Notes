package com.nond.attendance_manage.dao.impl;

import com.nond.attendance_manage.dao.WorkStatisticMonthRepository;
import com.nond.attendance_manage.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

@Repository
public class JdbcWorkStatisticMonthRepository implements WorkStatisticMonthRepository {
    private JdbcTemplate jdbcTemplate;
    private JdbcEmployeeRepository jdbcEmployeeRepository;
    private JdbcWorkArrangeRepository jdbcWorkArrangeRepository;
    private JdbcWorkStatisticFlexRepository jdbcWorkStatisticFlexRepository;
    private JdbcWorkStatisticDayRepository jdbcWorkStatisticDayRepository;

    @Autowired
    public JdbcWorkStatisticMonthRepository(
            JdbcTemplate jdbcTemplate,
            JdbcEmployeeRepository jdbcEmployeeRepository,
            JdbcWorkArrangeRepository jdbcWorkArrangeRepository,
            JdbcWorkStatisticFlexRepository jdbcWorkStatisticFlexRepository,
            JdbcWorkStatisticDayRepository jdbcWorkStatisticDayRepository) {
        this.jdbcTemplate = jdbcTemplate;
        this.jdbcEmployeeRepository = jdbcEmployeeRepository;
        this.jdbcWorkArrangeRepository = jdbcWorkArrangeRepository;
        this.jdbcWorkStatisticFlexRepository = jdbcWorkStatisticFlexRepository;
        this.jdbcWorkStatisticDayRepository = jdbcWorkStatisticDayRepository;
    }

    @Override
    public WorkStatisticMonth find(int employeeID, String date) {
        WorkStatisticMonth workStatisticMonth;
        try {
            save(employeeID, date);
            workStatisticMonth = jdbcTemplate.queryForObject(
                    "select * from WorkStatistic_Month where employeeID=? and date=?",
                    this::mapRow2WorkStatisticMonth,
                    employeeID, date);
            return workStatisticMonth;
        } catch (Exception e1) {
            return null;
        }
    }

    @Override
    public WorkStatisticMonth save(int employeeID, String date) {
        Employee employee = jdbcEmployeeRepository.findOne(employeeID);
        int year = Integer.parseInt(date.split("-")[0]) - 1900;
        int month = Integer.parseInt(date.split("-")[1]) - 1;
        if (employee == null)
            return null;
        Date date1 = new Date();
        date1.setYear(year);
        date1.setMonth(month);
        date1.setDate(1);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date1);
        date1.setDate(calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        if (employee.isFlexible()) {
            WorkStatisticFlex workStatisticFlex = jdbcWorkStatisticFlexRepository.findOne(employeeID, date1);
            if (workStatisticFlex != null)
                jdbcTemplate.update(
                        "insert into WorkStatistic_Month(employeeID,workCount,date,isFinish) values(?,?,?,?)",
                        employeeID,
                        workStatisticFlex.getLength(),
                        date,
                        workStatisticFlex.getEarningLength() >= 0);
        } else {
            int requiredDays = 0;
            int actualDays = 0;
            Iterable<WorkArrange> arranges = jdbcWorkArrangeRepository.findByMonth(employeeID, date1);
            Iterable<WorkStatisticDay> statisticDays = jdbcWorkStatisticDayRepository.findByMonth(employeeID, date1);
            for (WorkArrange ignored : arranges)
                requiredDays++;
            for (WorkStatisticDay ignored : statisticDays)
                actualDays++;
            jdbcTemplate.update(
                    "insert into WorkStatistic_Month(employeeID,workCount,date,isFinish) values(?,?,?,?)",
                    employeeID,
                    actualDays,
                    date,
                    actualDays >= requiredDays);
        }

        return null;
    }

    WorkStatisticMonth mapRow2WorkStatisticMonth(ResultSet resultSet, int i) throws SQLException {
        return new WorkStatisticMonth(
                resultSet.getInt("id"),
                resultSet.getInt("employeeID"),
                resultSet.getFloat("workCount"),
                resultSet.getString("date"),
                resultSet.getBoolean("isFinish")
        );
    }
}
