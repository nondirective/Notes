package com.nond.attendance_manage.dao.impl;

import com.nond.attendance_manage.dao.ManagerRepository;
import com.nond.attendance_manage.model.Manager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class JdbcManagerRepository implements ManagerRepository {
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public JdbcManagerRepository(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Manager find(String username, String password) {
        try{
            return jdbcTemplate.queryForObject("select * from Manager where username=? and password=?",this::mapRow2Manager,username,password);
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public Manager find(String username) {
        try{
            return jdbcTemplate.queryForObject("select * from Manager where username=?",this::mapRow2Manager,username);
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public Manager save(Manager manager) {
        jdbcTemplate.update(
                "insert into Manager(username,password) values(?,?)",
                manager.getUsername(),
                manager.getPassword());
        return manager;
    }

    @Override
    //Dao实现
    public void update(String username, String newPassword) {
        jdbcTemplate.update("update Manager set password=? where username=?",newPassword,username);
    }

    Manager mapRow2Manager(ResultSet resultSet,int rowNum) throws SQLException {
        return new Manager(
                resultSet.getInt("id"),
                resultSet.getString("username"),
                resultSet.getString("password"));
    }
}
