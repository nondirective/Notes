package com.nond.attendance_manage.dao.impl;


import com.nond.attendance_manage.dao.WorkStatisticDayRepository;
import com.nond.attendance_manage.model.ClockRecord;
import com.nond.attendance_manage.model.WorkArrange;
import com.nond.attendance_manage.model.WorkStatisticDay;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import static com.nond.attendance_manage.model.ClockRecord.ClockType;

@Repository
public class JdbcWorkStatisticDayRepository implements WorkStatisticDayRepository {
    private JdbcTemplate jdbcTemplate;
    private JdbcWorkArrangeRepository jdbcWorkArrangeRepository;
    private JdbcClockRecordRepository jdbcClockRecordRepository;

    @Autowired
    public JdbcWorkStatisticDayRepository(
            JdbcTemplate jdbcTemplate,
            JdbcWorkArrangeRepository jdbcWorkArrangeRepository,
            JdbcClockRecordRepository jdbcClockRecordRepository) {
        this.jdbcTemplate = jdbcTemplate;
        this.jdbcWorkArrangeRepository = jdbcWorkArrangeRepository;
        this.jdbcClockRecordRepository = jdbcClockRecordRepository;
    }

    @Override
    public WorkStatisticDay find(int employeeID, Date date) {
        WorkStatisticDay workStatisticDay;
        try {
            save(employeeID, date);
            workStatisticDay = jdbcTemplate.queryForObject(
                    "select * from WorkStatistic_Day where employeeID=? and date=?",
                    this::mapRow2WorkStatisticDay,
                    employeeID, new java.sql.Date(date.getTime()));
            return workStatisticDay;
        } catch (Exception e2) {
            return null;
        }

    }

    @Override
    public WorkStatisticDay save(int employeeID, Date date) {
        WorkArrange workArrange = jdbcWorkArrangeRepository.find(employeeID, date);
        if (workArrange == null)
            return null;
        ClockRecord start = jdbcClockRecordRepository.findByID_Date_Type(employeeID, date, ClockType.IN);
        ClockRecord end = jdbcClockRecordRepository.findByID_Date_Type(employeeID, date, ClockType.OUT);
        if (start == null || end == null)
            return null;
        WorkStatisticDay workStatisticDay = new WorkStatisticDay(-1,
                employeeID,
                start.getClockTime(),
                end.getClockTime(),
                date,
                start.getClockTime().getHours() > workArrange.getStartTime().getHours() || (start.getClockTime().getMinutes() > workArrange.getStartTime().getMinutes()),
                end.getClockTime().getHours() < workArrange.getEndTime().getHours() || (end.getClockTime().getMinutes() < workArrange.getEndTime().getMinutes()));
        jdbcTemplate.update(
                "insert into WorkStatistic_Day(employeeID,startTime,endTime,date,isLateStart,isEarlyQuit) values(?,?,?,?,?,?)",
                employeeID,
                workStatisticDay.getStartTime(),
                workStatisticDay.getEndTime(),
                new java.sql.Date(date.getTime()),
                workStatisticDay.isLateStart(),
                workStatisticDay.isEarlyQuit());
        return workStatisticDay;
    }

    @Override
    public Iterable<WorkStatisticDay> findByMonth(int employeeID, Date date) {
        Date end = new java.sql.Date(date.getTime());
        Date start = new java.sql.Date(date.getTime());
        start.setDate(1);
        date.setDate(1);
        for(int i=1;i<=end.getDate();date.setDate(++i))
            save(employeeID, date);
        return jdbcTemplate.query(
                "select * from (select * from WorkStatistic_Day where employeeID=?) where date between ? and ? ",
                this::mapRow2WorkStatisticDay,
                employeeID,start, end);
    }

    WorkStatisticDay mapRow2WorkStatisticDay(ResultSet resultSet, int i) throws SQLException {
        return new WorkStatisticDay(
                resultSet.getInt("id"),
                resultSet.getInt("employeeID"),
                new Date(resultSet.getTime("startTime").getTime()),
                new Date(resultSet.getTime("endTime").getTime()),
                new Date(resultSet.getDate("date").getTime()),
                resultSet.getBoolean("isLateStart"),
                resultSet.getBoolean("isEarlyQuit")
        );
    }
}
