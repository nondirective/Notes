package com.nond.attendance_manage.controller;

import com.nond.attendance_manage.dao.WorkStatisticMonthRepository;
import com.nond.attendance_manage.dao.impl.JdbcEmployeeRepository;
import com.nond.attendance_manage.dao.impl.JdbcWorkStatisticMonthRepository;
import com.nond.attendance_manage.dao.impl.JdbcWorkStatisticDayRepository;
import com.nond.attendance_manage.dao.impl.JdbcWorkStatisticFlexRepository;
import com.nond.attendance_manage.model.WorkStatisticDay;
import com.nond.attendance_manage.model.WorkStatisticFlex;
import com.nond.attendance_manage.model.WorkStatisticMonth;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.websocket.server.PathParam;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@Controller
@Slf4j
@RequestMapping("manage/statistic")
public class StatisticController {
    private JdbcWorkStatisticFlexRepository jdbcWorkStatisticFlexRepository;
    private JdbcWorkStatisticDayRepository jdbcWorkStatisticDayRepository;
    private JdbcWorkStatisticMonthRepository jdbcWorkStatisticMonthRepository;
    private JdbcEmployeeRepository jdbcEmployeeRepository;
    private SimpleDateFormat sdf_d =  new SimpleDateFormat( "yyyy-MM-dd" );
    private SimpleDateFormat sdf_time = new SimpleDateFormat( "hh:mm" );
    private SimpleDateFormat sdf_date = new SimpleDateFormat( "yyyy年MM月dd日" );
    private SimpleDateFormat sdf_date_m = new SimpleDateFormat( "yyyy年MM月" );
    @Autowired
    public StatisticController(
            JdbcWorkStatisticFlexRepository jdbcWorkStatisticFlexRepository,
            JdbcWorkStatisticDayRepository jdbcWorkStatisticDayRepository,
            JdbcWorkStatisticMonthRepository jdbcWorkStatisticMonthRepository,
            JdbcEmployeeRepository jdbcEmployeeRepository){
        this.jdbcWorkStatisticFlexRepository = jdbcWorkStatisticFlexRepository;
        this.jdbcWorkStatisticDayRepository = jdbcWorkStatisticDayRepository;
        this.jdbcWorkStatisticMonthRepository = jdbcWorkStatisticMonthRepository;
        this.jdbcEmployeeRepository = jdbcEmployeeRepository;
    }

    @GetMapping("workStatisticFlex")
    public String workStatisticFlex(
            @PathParam("employeeID")String employeeID,
            @PathParam("date")String date,
            Model model) throws ParseException {
        WorkStatisticFlex workStatisticFlex = jdbcWorkStatisticFlexRepository.findOne(Integer.parseInt(employeeID),sdf_d.parse(date));
        if(workStatisticFlex!=null){
            model.addAttribute("wsf",workStatisticFlex);
            model.addAttribute("wsf_date",sdf_date.format(workStatisticFlex.getDate()));
            return "msg_wsFlex";
        }else{
            model.addAttribute("err_msg","结果不存在");
            model.addAttribute("redirect_url","3;url=workStatisticFlexSearch");
            return "err";
        }
    }

    @GetMapping("workStatisticDay")
    public String workStatisticDay(
            @PathParam("employeeID")String employeeID,
            @PathParam("date")String date,
            Model model) throws ParseException {
        WorkStatisticDay workStatisticDay = jdbcWorkStatisticDayRepository.find(Integer.parseInt(employeeID),sdf_d.parse(date));
        if(workStatisticDay!=null){
            model.addAttribute("wsd",workStatisticDay);
            model.addAttribute("sta_time",sdf_time.format(workStatisticDay.getStartTime()));
            model.addAttribute(("end_time"),sdf_time.format(workStatisticDay.getEndTime()));
            model.addAttribute("msg_date",sdf_date.format(workStatisticDay.getDate()));
            return "msg_wsDay";
        }else{
            model.addAttribute("err_msg","结果不存在");
            model.addAttribute("redirect_url","3;url=workStatisticDaySearch");
            return "err";
        }
    }

    @GetMapping("workStatisticMonth")
    public String workStatisticMonth(
            @PathParam("employeeID")String employeeID,
            @PathParam("date")String date,
            Model model) throws ParseException {
        WorkStatisticMonth workStatisticMonth = jdbcWorkStatisticMonthRepository.find(Integer.parseInt(employeeID),date);
        if(workStatisticMonth!=null){
            model.addAttribute("wsm_id",workStatisticMonth.getEmployeeID());
            model.addAttribute("wsm_length",jdbcEmployeeRepository.findOne(workStatisticMonth.getEmployeeID()).isFlexible()?
                    workStatisticMonth.getWorkCount()+"小时":workStatisticMonth.getWorkCount()+"天");

            model.addAttribute("wsm_isfins",workStatisticMonth.isFinish());
            model.addAttribute("wsm_date",workStatisticMonth.getDate());
            return "msg_wsMonth";
        }else{
            model.addAttribute("err_msg","结果不存在");
            model.addAttribute("redirect_url","3;url=workStatisticMonthSearch");
            return "err";
        }
    }
}
