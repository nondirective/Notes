package com.nond.attendance_manage.dao;

import com.nond.attendance_manage.model.WorkStatisticMonth;

import java.util.Date;

public interface WorkStatisticMonthRepository {
    public WorkStatisticMonth find(int employeeID, String date);
    public WorkStatisticMonth save(int employeeID,String date);
}
