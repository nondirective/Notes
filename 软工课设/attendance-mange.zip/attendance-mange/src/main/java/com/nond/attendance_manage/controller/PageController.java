package com.nond.attendance_manage.controller;

import com.nond.attendance_manage.model.ClockRecord;
import com.nond.attendance_manage.model.Manager;
import com.nond.attendance_manage.model.TO.PasswordTO;
import com.nond.attendance_manage.model.TO.WorkArrangeTO;
import com.nond.attendance_manage.model.TO.WorkLengthRequiredTO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

@Controller
public class PageController {
    @GetMapping()
    public String home(Model model) {
        model.addAttribute("clockRecord", new ClockRecord());
        return "home";
    }

    @GetMapping("manage")
    public String mangerLoginPage(Model model, HttpServletRequest httpServletRequest) {
        Cookie[] cookies = httpServletRequest.getCookies();
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals("u_token"))
                return "manageIndex";
        }

        model.addAttribute("manager", new Manager());
        model.addAttribute("msg_username", "");
        model.addAttribute("msg_password", "");
        return "managerLoginPage";
    }

    @GetMapping("manage/workArrange")
    public String workArrangePage(Model model) {
        model.addAttribute("workArrangeTO", new WorkArrangeTO());
        model.addAttribute("msg", "");
        return "workArrange";
    }

    @GetMapping("manage/workLengthRequired")
    public String workLengthRequierdPage(Model model) {
        model.addAttribute("workLengthRequiredTO", new WorkLengthRequiredTO());
        return "workLengthRequired";
    }

    @GetMapping("manage/statistic/workStatisticFlexSearch")
    public String workStatisticFlexSearch() {
        return "workStatisticFlexSearch";
    }

    @GetMapping("manage/statistic/workStatisticDaySearch")
    public String workStatisticDaySearch() {
        return "workStatisticDaySearch";
    }

    @GetMapping("manage/statistic/workStatisticMonthSearch")
    public String workStatisticMonthSearch(){
        return "workStatisticMonthSearch";
    }

    @GetMapping("manage/alterPassword")
    public String alterPasswordPage(Model model){
        model.addAttribute("passwordTO",new PasswordTO());
        return "alterPassword";
    }
}
