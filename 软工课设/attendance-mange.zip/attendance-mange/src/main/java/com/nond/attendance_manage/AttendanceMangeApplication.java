package com.nond.attendance_manage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendanceMangeApplication {

    public static void main(String[] args) {
        SpringApplication.run(AttendanceMangeApplication.class, args);
    }

}
