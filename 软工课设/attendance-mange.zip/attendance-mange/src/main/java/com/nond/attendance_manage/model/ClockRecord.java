package com.nond.attendance_manage.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.util.Date;

//实体类
@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class ClockRecord {
    private Integer id;
    private Integer employeeID;
    private ClockType clockType;
    private Date clockTime;
    private Date date;
    public static enum ClockType{IN,OUT};

    public void setClockType(String clockType){
        this.clockType = ClockType.valueOf(clockType);
    }
}
