package com.nond.attendance_manage.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class WorkStatisticDay {
    private int id;
    private int employeeID;
    private Date startTime;
    private Date endTime;
    private Date date;
    private boolean isLateStart;
    private boolean isEarlyQuit;
}
