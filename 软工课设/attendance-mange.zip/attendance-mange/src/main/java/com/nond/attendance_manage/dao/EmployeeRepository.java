package com.nond.attendance_manage.dao;

import com.nond.attendance_manage.model.Employee;

public interface EmployeeRepository {
    public Iterable<Employee> findAll();
    public Employee findOne(int id);
    public Employee findOneByName(String name);
    public Employee save(Employee employee);
    public Iterable<Integer> findAllID();
}
