package com.nond.attendance_manage.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class WorkStatisticFlex {
    private int id;
    private int employeeID;
    private float length;
    private float earningLength;
    private Date date;
}
