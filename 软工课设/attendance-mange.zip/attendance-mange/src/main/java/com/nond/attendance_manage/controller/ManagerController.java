package com.nond.attendance_manage.controller;

import com.nond.attendance_manage.dao.impl.JdbcManagerRepository;
import com.nond.attendance_manage.model.TO.PasswordTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;


import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.regex.Pattern;

@Controller
public class ManagerController {
    private static final String REGEX_PASSWORD = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{6,20}$";
    @Autowired
    private JdbcManagerRepository jdbcManagerRepository;

    @PostMapping("manage/alterPassword")
    public String alterPassword(PasswordTO passwordTO, Model model, HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse){
        if(!passwordTO.getNewPassword().equals(passwordTO.getCheckPassword())){
            model.addAttribute("err_msg","两次输入不一致");
            model.addAttribute("redirect_url","3;url=/manage/alterPassword");
            return "err";
        }
        if(!Pattern.matches(REGEX_PASSWORD,passwordTO.getNewPassword())){
            model.addAttribute("err_msg","密码格式应为6-20个字符，至少1个字母，1个数字和1个特殊字符");
            model.addAttribute("redirect_url","3;url=/manage/alterPassword");
            return "err";
        }
        Cookie[] cookies = httpServletRequest.getCookies();
        String username = null;
        for (Cookie cookie : cookies)
            if (cookie.getName().equals("u_token")){
                username = cookie.getValue();
                break;
            }

        if(username==null){
            model.addAttribute("err_msg","用户未登录");
            model.addAttribute("redirect_url","3;url=/manage");
            return "err";
        }

        if(jdbcManagerRepository.find(username,passwordTO.getOldPassword())==null){
            model.addAttribute("err_msg","原密码错误");
            model.addAttribute("redirect_url","3;url=/manage/alterPassword");
            return "err";
        }

        jdbcManagerRepository.update(username,passwordTO.getNewPassword());
        Cookie cookie = new Cookie("u_token",username);
        cookie.setMaxAge(0);
        httpServletResponse.addCookie(cookie);
        return "redirect:/";
    }
}
