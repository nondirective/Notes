package com.nond.attendance_manage.controller;

import com.nond.attendance_manage.dao.impl.JdbcWorkArrangeRepository;
import com.nond.attendance_manage.model.TO.WorkArrangeTO;
import com.nond.attendance_manage.model.WorkArrange;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Date;

@Slf4j
@Controller
@RequestMapping("manage/workArrange")
public class WorkArrangeController {
    private JdbcWorkArrangeRepository jdbcWorkArrangeRepository;

    @Autowired
    public WorkArrangeController(JdbcWorkArrangeRepository jdbcWorkArrangeRepository){
        this.jdbcWorkArrangeRepository = jdbcWorkArrangeRepository;
    }

    @PostMapping("/saveWorkArrange")
    public String saveWorkArrange(WorkArrangeTO workArrangeTO){
        log.info(workArrangeTO.toString());
        for(Date date:workArrangeTO.getDates()){
            jdbcWorkArrangeRepository.save(
                    new WorkArrange(-1,
                            workArrangeTO.getEmployeeID(),
                            workArrangeTO.getStartTime(),
                            workArrangeTO.getEndTime(),
                            date));
        }
        return "redirect:/manage/workArrange";
    }
}
