package com.nond.attendance_manage.controller;

import com.nond.attendance_manage.dao.impl.JdbcEmployeeRepository;
import com.nond.attendance_manage.dao.impl.JdbcWorkLengthRequiredRepository;
import com.nond.attendance_manage.model.TO.WorkLengthRequiredTO;
import com.nond.attendance_manage.model.WorkLengthRequired;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Slf4j
public class WorkLengthRequiredController {
    private JdbcWorkLengthRequiredRepository jdbcWorkLengthRequiredRepository;
    private JdbcEmployeeRepository jdbcEmployeeRepository;
    @Autowired
    public WorkLengthRequiredController(
            JdbcWorkLengthRequiredRepository jdbcWorkLengthRequiredRepository,
            JdbcEmployeeRepository jdbcEmployeeRepository){
        this.jdbcWorkLengthRequiredRepository = jdbcWorkLengthRequiredRepository;
        this.jdbcEmployeeRepository = jdbcEmployeeRepository;
    }

    @PostMapping("manage/workLengthRequired")
    public String workLengthRequired(WorkLengthRequiredTO workLengthRequiredTO){
        if(workLengthRequiredTO.isSetAll()){
            setAll(workLengthRequiredTO.getLength(),workLengthRequiredTO.getDate());
        }else{
            jdbcWorkLengthRequiredRepository.save(
                    jdbcEmployeeRepository.findOneByName(workLengthRequiredTO.getName()).getEmployeeID(),
                    workLengthRequiredTO.getLength(),
                    workLengthRequiredTO.getDate()
            );
        }
        return "workLengthRequired";
    }

    private void setAll(float length, String date){
        Iterable<Integer> ids = jdbcEmployeeRepository.findAllID();
        for(int id:ids){
            WorkLengthRequired obj = jdbcWorkLengthRequiredRepository.find(id,date);
            if(obj!=null && obj.getLength()!=length)
                jdbcWorkLengthRequiredRepository.update(obj.getId(),length);
            else
                jdbcWorkLengthRequiredRepository.save(id,length,date);
        }
    }
}
