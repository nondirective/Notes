package com.nond.attendance_manage.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Employee {
    private int employeeID;
    private String name;
    private boolean isFlexible;
}
