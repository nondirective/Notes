package com.nond.attendance_manage.model.TO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.validation.constraints.Pattern;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class PasswordTO {
    private String oldPassword;
    private String newPassword;
    private String checkPassword;
}
