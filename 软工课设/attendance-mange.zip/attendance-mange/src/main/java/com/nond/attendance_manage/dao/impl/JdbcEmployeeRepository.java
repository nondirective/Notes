package com.nond.attendance_manage.dao.impl;

import com.nond.attendance_manage.dao.EmployeeRepository;
import com.nond.attendance_manage.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;

@Repository
public class JdbcEmployeeRepository implements EmployeeRepository {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public Iterable<Employee> findAll() {
        return jdbcTemplate.query(
                "SELECT * FROM Employee",
                this::mapRow2Employee);
    }

    @Override
    public Employee findOne(int id) {
        try {
            return jdbcTemplate.queryForObject("SELECT * FROM Employee WHERE id=?", this::mapRow2Employee, id);
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public Employee findOneByName(String name) {
       try {
           return jdbcTemplate.queryForObject(
                   "select * from Employee where name=?",
                   this::mapRow2Employee,
                   name);
       }catch (Exception e){
           return null;
       }
    }

    @Override
    public Employee save(Employee employee) {
        jdbcTemplate.update("INSERT INTO Employee(name,isFlexible) VALUES(?,?)",
                employee.getName(),
                employee.isFlexible());
        return employee;
    }

    @Override
    public Iterable<Integer> findAllID() {
        return jdbcTemplate.query("select id from Employee",this::mapRow2Integer);

    }

    Employee mapRow2Employee(ResultSet rs,int rowNum) throws SQLException {
        return new Employee(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getBoolean("isFlexible"));
    }

    private int mapRow2Integer(ResultSet resultSet,int rowNum) throws SQLException {
        return resultSet.getInt("id");
    }
}
