package com.nond.attendance_manage.dao;

import com.nond.attendance_manage.model.ClockRecord;
import static com.nond.attendance_manage.model.ClockRecord.ClockType;
import java.util.Date;

public interface ClockRecordRepository {
    Iterable<ClockRecord> findByDate(Date date);
    Iterable<ClockRecord> findByID(int employeeID);
    Iterable<ClockRecord> findByID_Type_Month(int employeeID,Date date,ClockType clockType);
    ClockRecord findByID_Date_Type(int employeeID, Date date,ClockType type);
    ClockRecord save(ClockRecord clockRecord);
}
