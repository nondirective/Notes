package com.nond.attendance_manage.dao.impl;

import com.nond.attendance_manage.dao.WorkStatisticFlexRepository;
import com.nond.attendance_manage.model.ClockRecord;
import com.nond.attendance_manage.model.WorkStatisticFlex;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import static com.nond.attendance_manage.model.ClockRecord.ClockType;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

@Repository
public class JdbcWorkStatisticFlexRepository implements WorkStatisticFlexRepository {
    private JdbcTemplate jdbcTemplate;
    private JdbcClockRecordRepository jdbcClockRecordRepository;
    private JdbcWorkLengthRequiredRepository jdbcWorkLengthRequiredRepository;

    @Autowired
    public JdbcWorkStatisticFlexRepository(
            JdbcTemplate jdbcTemplate,
            JdbcClockRecordRepository jdbcClockRecordRepository,
            JdbcWorkLengthRequiredRepository jdbcWorkLengthRequiredRepository) {
        this.jdbcTemplate = jdbcTemplate;
        this.jdbcClockRecordRepository = jdbcClockRecordRepository;
        this.jdbcWorkLengthRequiredRepository = jdbcWorkLengthRequiredRepository;
    }

    @Override
    public WorkStatisticFlex save(int employeeID, Date date) {
        Iterable<ClockRecord> start = jdbcClockRecordRepository.findByID_Type_Month(employeeID, date, ClockType.IN);
        Iterable<ClockRecord> end = jdbcClockRecordRepository.findByID_Type_Month(employeeID, date, ClockType.OUT);
        float length = 0;
        for (ClockRecord record : start) {
            for (ClockRecord record1 : end) {
                if (record.getDate().getDay() == record1.getDate().getDay()) {
                    length += (record1.getClockTime().getTime() - record.getClockTime().getTime()) / 3600000;
                    break;
                }
            }
        }

        WorkStatisticFlex workStatisticFlex = new WorkStatisticFlex();
        workStatisticFlex.setEmployeeID(employeeID);
        workStatisticFlex.setLength(length);
        StringBuffer sb = new StringBuffer();
        sb.append((1900 + date.getYear()) + "-");
        sb.append((1 + date.getMonth()) < 10 ? "0" + (1 + date.getMonth()) : 1 + date.getMonth() + "");
        jdbcTemplate.update(
                "insert into WorkStatistic_Flex(employeeID,length,earningLength,date) values(?,?,?,?)",
                employeeID,
                length,
                length - jdbcWorkLengthRequiredRepository.find(employeeID, sb.toString()).getLength(),
                new java.sql.Date(date.getTime()));
        return workStatisticFlex;
    }

    @Override
    public WorkStatisticFlex findOne(int employeeID, Date date) {
        WorkStatisticFlex workStatisticFlex;
        try {
            save(employeeID, date);
            workStatisticFlex = jdbcTemplate.queryForObject(
                    "select * from WorkStatistic_Flex where employeeID=? and date =?",
                    this::mapRow2WorkStatisticFlex,
                    employeeID, new java.sql.Date(date.getTime()));
            return workStatisticFlex;
        } catch (Exception e2) {
            return null;
        }

    }

    WorkStatisticFlex mapRow2WorkStatisticFlex(ResultSet resultSet, int i) throws SQLException {
        return new WorkStatisticFlex(
                resultSet.getInt("id"),
                resultSet.getInt("employeeID"),
                resultSet.getFloat("length"),
                resultSet.getFloat("earningLength"),
                new Date(resultSet.getDate("date").getTime())
        );
    }
}
