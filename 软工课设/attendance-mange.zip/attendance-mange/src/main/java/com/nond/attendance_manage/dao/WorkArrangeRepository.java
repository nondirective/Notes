package com.nond.attendance_manage.dao;

import com.nond.attendance_manage.model.WorkArrange;
import org.springframework.stereotype.Repository;

import java.util.Date;

public interface WorkArrangeRepository {
    public WorkArrange find(int employeeID,Date date);
    public WorkArrange save(WorkArrange workArrange);
    public Iterable<WorkArrange> findByMonth(int employeeID,Date date);
}
