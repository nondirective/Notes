package com.nond.attendance_manage.dao;

import com.nond.attendance_manage.model.Manager;

public interface ManagerRepository {
    public Manager find(String username,String password);
    public Manager find(String username);
    public Manager save(Manager manager);
    public void update(String username, String newPassword);
}
