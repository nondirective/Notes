package com.nond.attendance_manage.dao.impl;

import com.nond.attendance_manage.dao.WorkArrangeRepository;
import com.nond.attendance_manage.model.WorkArrange;
import lombok.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Date;

@Repository
public class JdbcWorkArrangeRepository implements WorkArrangeRepository {
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public JdbcWorkArrangeRepository(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public WorkArrange find(int employeeID,Date date) {
        try {
            return jdbcTemplate.queryForObject(
                    "select * from WorkArrange where date=? and employeeID=?",
                    this::mapRow2WorkArrange,
                    new java.sql.Date(date.getTime()),employeeID
            );
        }catch(Exception e){
            return null;
        }
    }

    @Override
    public WorkArrange save(WorkArrange workArrange) {
        if(find(workArrange.getEmployeeID(),workArrange.getDate())!=null){
            jdbcTemplate.update(
                    "update WorkArrange set startTime=?,endTime=? where date=? and employeeID = ?",
                    new Time(workArrange.getStartTime().getTime()),
                    new Time(workArrange.getEndTime().getTime()),
                    new Date(workArrange.getDate().getTime()),
                    workArrange.getEmployeeID()
            );
        }else {
            jdbcTemplate.update(
                    "insert into WorkArrange(startTime,endTime,date,employeeID) values (?,?,?,?)",
                    new Time(workArrange.getStartTime().getTime()),
                    new Time(workArrange.getEndTime().getTime()),
                    new java.sql.Date(workArrange.getDate().getTime()),
                    workArrange.getEmployeeID()
            );
        }
        return workArrange;
    }

    @Override
    public Iterable<WorkArrange> findByMonth(int employeeID, Date date) {
        Date start = new java.sql.Date(date.getTime());
        Date end = new java.sql.Date(date.getTime());
        start.setDate(1);
        return jdbcTemplate.query(
                "select * from WorkArrange where date>=? and date <=? and employeeID=?",
                this::mapRow2WorkArrange,
                start,end,employeeID);
    }

    WorkArrange mapRow2WorkArrange(ResultSet resultSet,int rowNum) throws SQLException {
        return new WorkArrange(
                resultSet.getInt("id"),
                resultSet.getInt("employeeID"),
                new Date(resultSet.getTime("startTime").getTime()),
                new Date(resultSet.getTime("endTime").getTime()),
                new Date(resultSet.getDate("date").getTime())
        );
    }
}
