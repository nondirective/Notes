package com.nond.attendance_manage.dao;

import com.nond.attendance_manage.model.WorkStatisticDay;

import java.util.Date;

public interface WorkStatisticDayRepository {
    public WorkStatisticDay find(int employeeID, Date date);
    public WorkStatisticDay save(int employeeID, Date date);
    Iterable<WorkStatisticDay> findByMonth(int employeeID, Date date);
}
