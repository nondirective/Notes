package com.nond.attendance_manage.model.TO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class WorkArrangeTO {
    private Date startTime;
    private Date endTime;
    private int employeeID;
    private List<Date> dates;

    public void setStartTime(String string){
        Date date = new Date();
        String[] times = string.split(":");
        date.setHours(Integer.parseInt(times[0]));
        date.setMinutes(Integer.parseInt(times[1]));
        date.setSeconds(0);
        this.startTime = date;
    }

    public void setEndTime(String string){
        Date date = new Date();
        String[] times = string.split(":");
        date.setHours(Integer.parseInt(times[0]));
        date.setMinutes(Integer.parseInt(times[1]));
        date.setSeconds(0);
        this.endTime = date;
    }

    public void setDates(List<String> strings){
        this.dates = new ArrayList<Date>();
        for(String string:strings){
            Date date = new Date();
            String[] times = string.split("-");
            date.setYear(Integer.parseInt(times[0])-1900);
            date.setMonth(Integer.parseInt(times[1])-1);
            date.setDate(Integer.parseInt(times[2]));
            date.setSeconds(0);
            this.dates.add(date);
        }
    }
}
