package com.nond.attendance_manage.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class WorkLengthRequired {
    int id;
    int employeeID;
    float length;
    String date;
}
