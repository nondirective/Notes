package com.nond.attendance_manage.controller;

import com.nond.attendance_manage.dao.impl.JdbcClockRecordRepository;
import com.nond.attendance_manage.dao.impl.JdbcEmployeeRepository;
import com.nond.attendance_manage.model.ClockRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.Date;

@Controller
@Slf4j
@RequestMapping("/clock")
public class ClockController {
    private JdbcClockRecordRepository jdbcClockRecordRepository;
    private JdbcEmployeeRepository jdbcEmployeeRepository;
    @Autowired
    public ClockController(JdbcClockRecordRepository jdbcClockRecordRepository,
                           JdbcEmployeeRepository jdbcEmployeeRepository){
        this.jdbcClockRecordRepository = jdbcClockRecordRepository;
        this.jdbcEmployeeRepository = jdbcEmployeeRepository;
    }

    //控制器实现
    @PostMapping
    public String clock(ClockRecord clockRecord, Model model){
        clockRecord = jdbcClockRecordRepository.save(clockRecord);
        model.addAttribute("time",new Date(clockRecord.getClockTime().getTime()));
        model.addAttribute("name",jdbcEmployeeRepository.findOne(clockRecord.getEmployeeID()).getName());
        model.addAttribute("clockType",clockRecord.getClockType().name().equals("IN")?"上班卡":"下班卡");
        return "message";
    }
}
