package com.nond.attendance_manage.dao;

import com.nond.attendance_manage.model.WorkLengthRequired;


public interface WorkLengthRequiredRepository {
    public void save(WorkLengthRequired workLengthRequired);
    public void save(int id, float length, String date);
    public WorkLengthRequired find(int employeeID, String date);
    public void update(int id, float length);
}
