package com.nond.attendance_manage.dao.impl;

import com.nond.attendance_manage.dao.WorkLengthRequiredRepository;
import com.nond.attendance_manage.model.WorkLengthRequired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class JdbcWorkLengthRequiredRepository implements WorkLengthRequiredRepository {
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public JdbcWorkLengthRequiredRepository(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }
    @Override
    public void save(WorkLengthRequired workLengthRequired) {
        WorkLengthRequired obj = find(workLengthRequired.getEmployeeID(), workLengthRequired.getDate());
        if(obj!=null && obj.getLength()!=workLengthRequired.getLength()){
            jdbcTemplate.update("update WorkLengthRequired set length=? where id=?",obj.getId());
        }else{
            jdbcTemplate.update(
                    "insert into WorkLengthRequired(employeeID,length,date) values(?,?,?)",
                    workLengthRequired.getEmployeeID(),
                    workLengthRequired.getLength(),
                    workLengthRequired.getDate()
            );
        }
    }

    @Override
    public void save(int id, float length, String date) {
        jdbcTemplate.update("insert into WorkLengthRequired(employeeID,length,date) values(?,?,?)",
                id,length,date);
    }


    @Override
    public WorkLengthRequired find(int employeeID,String date) {
        try{
            return jdbcTemplate.queryForObject(
                    "select * from WorkLengthRequired where employeeID=? and date=?",
                    this::mapRow2WorkLengthRequired,
                    employeeID,date
            );
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public void update(int id, float length) {
        jdbcTemplate.update("update WorkLengthRequired set length=? where id=?",length,id);
    }

    WorkLengthRequired mapRow2WorkLengthRequired(ResultSet resultSet,int rowNum) throws SQLException {
        return new WorkLengthRequired(
                resultSet.getInt("id"),
                resultSet.getInt("employeeID"),
                resultSet.getFloat("length"),
                resultSet.getString("date")
        );
    }
}
