package com.nond.attendance_manage.controller;

import com.nond.attendance_manage.dao.impl.JdbcManagerRepository;
import com.nond.attendance_manage.model.Manager;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;

@Slf4j
@Controller
@RequestMapping("manage")
public class LoginController {
    private JdbcManagerRepository jdbcManagerRepository;

    @Autowired
    public  LoginController(JdbcManagerRepository jdbcManagerRepository){
        this.jdbcManagerRepository = jdbcManagerRepository;
    }

    @PostMapping("/login")
    public String login(Manager manager, Model model, HttpServletResponse response){
        if(jdbcManagerRepository.find(manager.getUsername())==null){
            model.addAttribute("msg_username","用户名不存在");
            return "managerLoginPage";
        }else if(jdbcManagerRepository.find(manager.getUsername(),manager.getPassword())==null){
            model.addAttribute("msg_password","密码错误");
            return "managerLoginPage";
        }
        Cookie cookie = new Cookie("u_token",manager.getUsername());
        cookie.setMaxAge(3600);
        response.addCookie(cookie);
        return "redirect:/manage";
    }
}
