package com.nond.attendance_manage.dao;

import com.nond.attendance_manage.model.WorkStatisticFlex;

import java.util.Date;

public interface WorkStatisticFlexRepository {
    public WorkStatisticFlex save(int employeeID, Date date);
    public WorkStatisticFlex findOne(int employeeID, Date date);
}
